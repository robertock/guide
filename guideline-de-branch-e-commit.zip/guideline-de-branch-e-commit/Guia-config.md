# Guia de configuração de CI/CD no Gitlab

### Pré-requisitos:
- Possuir o Gitlab runner instalado em uma máquina (atualmente a 'jenkinsdpi' na Azure)
Referência: https://docs.gitlab.com/runner/register/

### Configurando o Runner

1. Acessar o projeto que deseja configurar o CI/CD

2. Acessar o Settings > CI/CD > Runners
Exemplo:
![](Imagens/CICD-gitlab-1.PNG)

3. Ao descer a página irá encontrar o URL do projeto e o Token para configuração do Runner
Exemplo:
![](Imagens/CICD-gitlab-2.PNG)

4. Salvar o URL e o Token em algum lugar de fácil acesso, eles serão usados nos passos a seguir

5. Acessar por SSH a máquina com o Gitlab runner instalado

6. Executar o comando 'sudo gitlab-runner register'

7. O Gitlab Runner solicitará o URL do projeto
Exemplo:
![](Imagens/CICD-gitlab-3.png)

8. Insira o URL do projeto e pressione ENTER

9. O Gitlab Runner solicitará o Token do projeto
Exemplo:
![](Imagens/CICD-gitlab-4.png)

10. Insira o Token do projeto e pressione ENTER

11. O Gitlab Runner solicitará o nome do projeto
Exemplo:
![](Imagens/CICD-gitlab-5.png)

12. Insira o nome do projeto e pressione ENTER

13. O Gitlab Runner solicitará as tags do projeto
Exemplo:
![](Imagens/CICD-gitlab-6.png)

14. Insira as tags do projeto separadas por **,** e pressione ENTER

15. O Gitlab Runner solicitará o executor do projeto
Exemplo:
![](Imagens/CICD-gitlab-7.png)

16. Insira o executor do projeto e pressione ENTER (atualmente usamos o shell)

### Configurando o Pipeline

1. Acessar o projeto que deseja configurar o Pipeline

2. Crie um aquivo de configuração chamado gitlab-ci.yml na raiz do projeto

3. Acesse o arquivo de configuração e defina os estágios e os scripts que serão executados