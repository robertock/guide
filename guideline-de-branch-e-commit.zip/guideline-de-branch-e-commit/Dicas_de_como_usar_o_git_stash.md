# Guideline de branching e commit

## Usando o Git Stash

**1. Salvando modificações que não foram comitadas:**

```
$ git stash save "<mensagem de identificação>"
```
Exemplo:
```
git stash save "adicionar conteudo ao arquivo newFeature5"
```

**2. Listando modificações salvas:**

```
$ git stash list
```

- O resultado esperado da pesquisa do exemplo é:
```
$ stash@{0}: On newFeature8: adicionar conteudo ao arquivo newFeature5
```

**3. Retomando as modificações salvas:**
```
$ git stash apply stash@{0}
```

- Após terminar de trabalhar com as modificações salvas e commitar o trabalho que foi feito, você pode apagar o registro na pilha do stash usando o comando 'drop':
```
$ git stash drop stash@{0}
```

- Alternativamente, você pode usar o comando 'pop' para recuperar o progresso e apagar o registro na pilha do stash ao mesmo tempo:
```
$ git stash pop stash@{0}
```
