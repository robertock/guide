# Guideline de branching e commit


## Resolvendo conflitos no Git

**Durante uma operação de merge, pode ocorrer um conflito como o descrito abaixo:**
```
$ Auto-merging newFeature4.txt
$ CONFLICT (content): Merge conflict in newFeature4.txt
$ Automatic merge failed; fix conflicts and then commit the result.
```

**Isso é comum, não se preocupe.**

O Git identificou que uma ou mais modificações ocorreram no mesmo arquivo, e o Git não sabe qual é a certa. Logo, a melhor forma de resolver um conflito é analizar o conflito e identificar a causa.

## Exemplos de conflitos:

**1. Alterações não relacionadas:** As alteração são totalmente diferentes. **Solução:** o método em conflito "subtração" deve ser adicionado em outra posição do arquivo (em alguma linha mais abaixo que não entre em conflito com outras partes do arquivo).
```
<<<<<<< HEAD
float soma(float valor1, float valor2){
	return valor1 + valor2;
}
=======
float soma(float arg1, float arg2){
	return arg1 + arg2;
}
>>>>>>> Calculadora.java
```

**2. Alterações relacionadas:** As alterações ocorrem em um mesmo trecho, em uma mesma funcionalidade. Por exemplo, dois commits realizaram mudanças nos parâmetros do método soma. **Solução:** Nesse caso, é preciso verificar qual alteração será mantida, analisando alguns fatores como: 
- O nome dos argumentos segue o padrão utilizado no projeto? Exemplo: Se todos os argumentos são padronizados como valor1 e valor2, então a implementação do método soma coma argumentos arg1 e arg2 deve ser substituída.
- Complexidade de refatoração, qual a modificação implica em menos mudanças no projeto como um todo. Exemplo: Somente o commit atual possui chamadas utilizando arg1 e arg2, logo manter a implementação de arg1 e arg2 implicaria em mudanças desnecessárias no projeto.
```
<<<<<<< HEAD
float soma(float valor1, float valor2){
	return valor1 + valor2;
}
=======
float soma(float arg1, float arg2){
	return arg1 + arg2;
}
>>>>>>> Calculadora.java
```

**3. Alteração funcional:** A alteração muda o funcionamento. **Solução:** Analisar o conflito junto com o resto do time, neste caso no método media é preciso analisar a solução mais adequada, que poderia ser manter a primeira implementação e a segunda ser renomeada para mediaPonderada, mantendo as duas implementações apenas adicionando um método mediaPonderada e não alterando qualquer linha da implementação do método media.
```
<<<<<<< HEAD
float media(float valor1, float valor2){
	return (valor1 + valor2) / 2;
}
=======
float media(float valor1, float valor2){
	return(2*valor1 + 3*valor2)/2+3;
}
>>>>>>> Calculadora.java
```

## Exemplo Prático

1. Suponha a existência de um arquivo de texto chamado '**interface**' e duas branchs chamadas '**newFeature6**' e '**newFeature7**'.

2. Cada branch faz uma adiação de uma única linha de código no arquivo '**interface**'.
```
Dentro da branch newFeature6:
$ echo "Modificação feita na newFeature6" >> interface.txt
```
```
Dentro da branch newFeature7:
$ echo "Modificação feita na newFeature7" >> interface.txt
```

3. Ao tentar realizar a operação de merge das duas branchs com a develop, ocorre um conflito no segundo merge.
```
$ merge --no-ff newFeature6 develop
$ merge --no-ff newFeature7 develop
$ Auto-merging interface.txt
$ CONFLICT (content): Merge conflict in interface.txt
$ Automatic merge failed; fix conflicts and then commit the result.
```

4. Para resolver o conflito do exemplo, deve-se abrir o arquivo conflitante:
```
$ <comando_editor_texto> interface.txt
```

5. Esse é o conteúdo do arquivo que está em conflito:
```
<<<<<<< HEAD
Modificação feita na newFeature6
=======
Modificação feita na newFeature7
>>>>>>> newFeature7
```

6. Se o desejado fosse manter apenas o conteúdo da branch 'newFeature6', o conteúdo final do arquivo seria:
```
Modificação feita na newFeature6
```

7. Para fazer isso, a solução do conflito é remover as marcações do Git e o conteúdo da newFeature7:
```
$ <<<<<<< HEAD
$ =======
$ Modificação feita na newFeature7
$ >>>>>>> newFeature7
```

8. Neste caso, a solução que adotaremos é manter ambas as modificações, o conteúdo final do arquivo é:
```
Modificação feita na newFeature6

Modificação feita na newFeature7
```

9. Logo, só é necessário remover os indicadores do conflito colocados pelo Git:
```
$ <<<<<<< HEAD
$ =======
$ >>>>>>> newFeature7
```

10. Commitar o arquivo com os conflitos corrigidos para concluir a ação de 'merge':
```
$ git add interface.txt
$ git commit
```
