# Exercício de fixação do Guideline de branching e commit

Este guia tem o objetivo de servir como um exercício da compreensão e aplicação do [Guideline de branchig e commit](http://gitlabdpi.westus2.cloudapp.azure.com/blockchain/guideline-de-branch-e-commit/-/tree/master).

# Pré-requisitos
Os pré-requisitos para completar o exercício são:
1) Ter instalado os softwares **Notepad++**, **git** e **Sourcetree** listados no [manual de Onboarding do time](http://gitlabdpi.westus2.cloudapp.azure.com/blockchain/onboarding-pesquisa-dpi);
2) Ter concluído o treinamento de **Git** da **Udacity** listado no [manual de Onboarding do time](http://gitlabdpi.westus2.cloudapp.azure.com/blockchain/onboarding-pesquisa-dpi).

# Sobre o exercício
* O exercício consiste em utilizar o [Guideline de branchig e commit](http://gitlabdpi.westus2.cloudapp.azure.com/blockchain/guideline-de-branch-e-commit/-/tree/master) em um projeto simples de forma a identificar a real compreensão dos fundamentos, conceitos e uso dos comandos do software de versionamento de arquivos **git**;
* Utilize um repositório local. Não utilize o GitLab ou outra plataforma de versionamento remota;
* Anote qualquer problema ou erro na documentação para corrigi-lo.

# O exercício
Foi solicitado o desenvolvimento de uma página HTML e um arquivo CSS que apresentem as seguintes informações seguindo algumas especificações:
1) Quando a janela (ou aba) abrir, ela deve apresentar o título "*Olá Guide*" (para identificar a aba);
1) A cor de de fundo da página deve ser um tom de azul claro;
1) Dentro do corpo da página, a página deve apresentar o título "*Olá Guideline!*" em tamanho grande na cor vermelha;
1) Abaixo do título "*Olá Guideline!*", a página deve haver um parágrafo com o texto "*Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.*" na cor laranja.

## Atenção!
1) Siga as instruções conforme determinado. São esperadas algumas instruções intermediárias que não atendam a demanda de imediato para fins de exercício;
2) A numeração está incremental do início ao fim para facilitar ao seguir a sequência de tarefas;
3) Não use o **Sourcetree** para realizar as atividades e comandos deste exercício. Use-o apenas para facilitar a visualização dos commits e a evolução do que está sendo feito. Caso após um comando a tela do **Sourcetree** não mude, pressione F5 para atualizá-la. Com o tempo você aprenderá quando vale a pena usar o **Sourcetree**;

## Dicas
1) Anote os comandos utilizados em cada etapa;
2) Consulte o resultado esperado do exercício no final deste manual;
3) Se algum comando resultou em algo errado, revise o que foi digitado, encontre e busque entender o que ocasionou o erro. A hora de aprender, voltar, refazer é agora!
4) Salve versões intermediárias (faça cópias do diretório **ola-guideline**) antes de iniciar a próxima *Parte*. Por exemplo: antes de iniciar a *Parte 2*, copie todo o diretório **ola-guideline** e renomeie-o para **ola-guideline-parte1**. Caso alguma coisa saia errado, é mais rápido e fácil de corrigir;
5) O git possui algumas opções para reverter commits realizados com o comando **reset**: *soft*, *mixed*, *hard* e outros. Pesquise sobre como e quando usá-los;
6) Use o comando abaixo para remover (desfazer) o último commit executado, seja um commit ou um merge. Atente-se que as alterações realizadas nos arquivos também são desfeitas! Faça uma cópia do(s) arquivo(s) ou do(s) diretório(s) por segurança!
```
git reset --hard HEAD^
```

---

# Parte 1: inicialização do projeto
Faça os passos abaixo:
1) Abra em uma outra aba ou janela ou navegador a página do [Guideline de branchig e commit](http://gitlabdpi.westus2.cloudapp.azure.com/blockchain/guideline-de-branch-e-commit/-/tree/master);
2) Utilizando o Windows Explorer (ou outro gerenciador de arquivos), crie um diretório chamado "*ola-guideline*" em um local de fácil acesso no seu no seu ambiente de trabalho (p. ex.: na Área de Trabalho ou Desktop);
3) Acesse/entre no diretório **ola-guideline**;
4) Se estiver usando Windows, clique com o botão direito dentro do diretório (que deve estar vazio) e selecione a opção **Git Bash here**. Se estiver usando Linux, siga para a próxima instrução;

![Git Bash here](/Imagens/exercicio/git-bash-here.png)

5) Utilizando a as instruções do tópico **Início do projeto** do [Guideline de branchig e commit](http://gitlabdpi.westus2.cloudapp.azure.com/blockchain/guideline-de-branch-e-commit/-/tree/master), crie um novo repositório do Git com um arquivo README.md;
```
git init
echo "# Documentação do projeto" > README.md
git add README.md
git commit -m "Commit inicial do projeto"
```
6) No **Git Bash**, a partir do branch **master**, crie o branch **develop**;
```
git checkout -b develop master
```
7) Abra o Notepad++ (ou outro editor de texto), copie o trecho de código abaixo e cole-o em um novo arquivo. Salve o arquivo dentro do diretório **ola-guideline** com o nome e extensão **index.html**. Depois abra o arquivo **index.html** em um navegador e veja o resultado;
```
<!doctype html>
<html>
	<head>
		<title>Our HTML Page</title>
	</head>
	<body>
		Content goes here.
	</body>
</html>
```
![Resultado esperado](/Imagens/exercicio/parte-1-html.png)

8) No **Git Bash**, faça o commit desse arquivo dentro na branch **develop** com uma descrição adequada;
```
git status
git diff
git add index.html
git commit -m "Adicionar uma página HTML padrão"
```
9) No arquivo **index.html**, altere os conteúdos "*Our HTML Page**" por "*Olá Guide*" e "*Content goes here.*" por "*Olá Guideline!*". O conteúdo do arquivo deve ser o abaixo: 
```
<!doctype html>
<html>
	<head>
		<title>Olá Guide</title>
	</head>
	<body>
		Olá Guideline!
	</body>
</html>
```
10) Abra o arquivo **index.html** em um navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-1-html-2.png)

11) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;
```
git add index.html
git commit -m "Substituir conteúdo da página HTML padrão"
```

![Resultado esperado](/Imagens/exercicio/parte-1.png)

---

# Parte 2: a primeira funcionalidade
12) No **Git Bash**, a partir do branch **develop**, crie um branch chamado "*fundo-da-tela-colorido*";
13) No arquivo **index.html**, entre as tags **\<head>** e **\</head>**, adicione a linha abaixo:
```
<link rel="stylesheet" href="styles.css">
```
14) O conteúdo do arquivo deve ser o abaixo: 
```
<!doctype html>
<html>
	<head>
        <link rel="stylesheet" href="styles.css">
		<title>Olá Guide</title>
	</head>
	<body>
		Olá Guideline!
	</body>
</html>
```
15) Crie um novo arquivo em branco no Notepad++ (ou outro editor de texto), copie o trecho de código abaixo e cole-o nesse novo arquivo. Salve o arquivo dentro do diretório **ola-guideline** com o nome e extensão **styles.css**;
16) No arquivo **styles.css**, adicione as linhas abaixo e salve-o;
```
body {
  background-color: blue;
}
```
17) Atualize a página **index.html** aberta no navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-2-html.png)

18) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;
19) No arquivo **styles.css**, substitua a definição da cor "*blue*" por "*powderblue*" e salve-o;
20) O conteúdo do arquivo deve ser o abaixo:
```
body {
  background-color: powderblue;
}
```
21) Atualize a página **index.html** aberta no navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-2-html-2.png)

22) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;

![Resultado esperado](/Imagens/exercicio/parte-2.png)

---

# Parte 3: a segunda funcionalidade
23) No **Git Bash**, a partir do branch **develop**, faça o **merge** do que foi desenvolvido no branch **fundo-da-tela-colorido** com o branch **develop**;
```
git checkout develop
git merge --no-ff fundo-da-tela-colorido develop
```
24) No **Git Bash**, a partir do branch **develop**, crie um branch chamado "*texto-colorido*";
25) No arquivo **index.html**, entre as tags **\<body>** e **\</body>**, substitua o conteúdo da linha que contém o texto "*Olá Guideline!*" pelo conteúdo da linha abaixo e salve o arquivo;
```
<h1>Olá Guideline!</h1>
```
26) O conteúdo do arquivo deve ser o abaixo: 
```
<!doctype html>
<html>
	<head>
        <link rel="stylesheet" href="styles.css">
		<title>Olá Guide</title>
	</head>
	<body>
		<h1>Olá Guideline!</h1>
	</body>
</html>
```
27) Atualize a página **index.html** aberta no navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-3-html.png)

28) No arquivo **styles.css**, adicione as linhas abaixo no final do arquivo e salve-o;
```
h1 {
  color: blue;
}
```
23) O conteúdo do arquivo deve ser o abaixo: 
```
body {
  background-color: powderblue;
}

h1 {
  color: blue;
}
```
29) Atualize a página **index.html** aberta no navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-3-html-2.png)

30) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;
31) No arquivo **styles.css**, altere a cor dos elementos **h1** trocando a cor *blue* por "*red*" e salve-o;
```
h1 {
  color: red;
}
```
32) O conteúdo do arquivo deve ser o abaixo: 
```
body {
  background-color: powderblue;
}

h1 {
  color: red;
}
```
33) Atualize a página **index.html** aberta no navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-3-html-3.png)

34) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;

![Resultado esperado](/Imagens/exercicio/parte-3.png)

---

# Parte 4: a conclusão das primeiras funcionalidades
35) No **Git Bash**, faça o **merge** do que foi desenvolvido no branch **texto-colorido** com o branch **develop**;

![Resultado esperado](/Imagens/exercicio/parte-4.png)

---

# Parte 5: a entrega das primeiras funcionalidades
36) No **Git Bash**, a partir do branch **develop**, crie um branch chamado "*release*";
37) No **Git Bash**, a partir do branch **release**, faça o **merge** do que foi desenvolvido no branch **develop** com o branch **release**;
38) No **Git Bash**, aplique uma **tag** "*1.0.0*" para identificar a versão seguindo o no modelo semântico MAJOR.MINOR.PATCH;
```
git tag -a 1.0.0
```
39) No **Git Bash**, a partir do branch **master**, faça o **merge** da **develop** com o branch **master** para "entregar" a versão 1.0.0;

![Resultado esperado](/Imagens/exercicio/parte-5.png)

---

# Parte 6: a terceira funcionalidade
40) No **Git Bash**, a partir do branch **develop**, crie um branch chamado "*texto-longo-colorido*";
41) No arquivo **index.html**, entre as tags **\<body>** e **\</body>** e abaixo da linha **\<h1>Olá Guideline!\</h1>**, adicione o conteúdo abaixo e salve o arquivo;
```
<p>LoremLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<p>
```
42) O conteúdo do arquivo deve ser o abaixo: 
```
<!doctype html>
<html>
	<head>
        <link rel="stylesheet" href="styles.css">
		<title>Olá Guide</title>
	</head>
	<body>
		<h1>Olá Guideline!</h1>
        <p>LoremLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<p>
	</body>
</html>
```
43) No arquivo **styles.css**, adicione as linhas abaixo no final do arquivo e salve-o;
```
p {
  color: orange;
}
```
44) O conteúdo do arquivo deve ser o abaixo: 
```
body {
  background-color: powderblue;
}

h1 {
  color: red;
}

p {
  color: orange;
}
```
45) Atualize a página **index.html** aberta no navegador e perceba a mudança;

![Resultado esperado](/Imagens/exercicio/parte-4-html.png)

46) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;
47) No **Git Bash**, a partir do branch **develop**, faça o **merge** do que foi desenvolvido no branch **texto-longo-colorido** com o branch **develop**;
48) No **Git Bash**, a partir do branch **release**, faça o **merge** do que foi desenvolvido no branch **develop** com o branch **release**;
49) No **Git Bash**, aplique uma **tag** "*1.1.0*" para identificar a versão;
50) No **Git Bash**, a partir do branch **master**, faça o **merge** da **develop** com o branch **master** para "entregar" a versão 1.1.0;

![Resultado esperado](/Imagens/exercicio/parte-6.png)

51) Ops... Alguém detectou um erro no texto que foi adicionado nessa última versão que foi implantada (está na branch **master**!). Tem duas palavras "*Lorem*" no parágrafo. Precisamos corrigi-lo urgentemente!

---

# Parte 7: a primeira correção emergencial
52) No **Git Bash**, a partir do branch **master**, crie o branch **hotfix**;
53) No arquivo **index.html**, entre as tags **\<p>** e **\</p>**, localize a palavra "*Lorem*" repetida, remova-a e salve o arquivo;
54) O conteúdo do arquivo deve ser o abaixo: 
```
<!doctype html>
<html>
	<head>
        <link rel="stylesheet" href="styles.css">
		<title>Olá Guide</title>
	</head>
	<body>
		<h1>Olá Guideline!</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<p>
	</body>
</html>
```
55) Atualize a página **index.html** aberta no navegador e certifique-se que a correção é mudança esperada para atender o exercício;

![Resultado esperado](/Imagens/exercicio/parte-7-html.png)

56) No **Git Bash**, faça o **commit** das alterações com uma descrição adequada;
57) No **Git Bash**, aplique uma **tag** "*1.1.1*" para identificar a versão;

![Resultado esperado](/Imagens/exercicio/parte-7.png)

---

# Parte 8: a entrega do primeiro hotfix
58) No **Git Bash**, a partir do branch **master**, faça o **merge** do que foi desenvolvido no branch **hotfix** para o branch **master**;

![Resultado esperado](/Imagens/exercicio/parte-8.png)


# Parte 9: atualizar o develop com a correção do hotfix
59) No **Git Bash**, a partir do branch **develop**, faça o **merge** do que foi desenvolvido no branch **hotfix** com o branch **develop** para não comprometer a evolução do software;

![Resultado esperado](/Imagens/exercicio/parte-9.png)

60) Fim da parte prática.
---

# Parte 10: lições aprendidas
* Quais as lições aprendidas?
* O que pode melhorar?
* Quais comandos deram errado? Quais foram os erros?
* Verifique como ficou o resultado do grafo de commits do projeto. O resultado esperado é um grafo igual ao esperado?

---

# Parte 11: upload do projeto
1) Na tela inicial do GitLab (para acessá-la basta clicar no ícone do GitLab), crie um novo projeto.

![Novo projeto](/Imagens/exercicio/novo-projeto.png)

2) Selecione a opção de criar um projeto em branco.

![Projeto em branco](/Imagens/exercicio/projeto-em-branco.png)

3) A tela para configurar um novo projeto será apresentada.

![Novo projeto](/Imagens/exercicio/projeto-config-1.png)

4) Escreva o nome do projeto conforme informado anteriormente. O campo **Project slug** será completado automaticamente;
5) Em **Project URL** mantenha selecionado o nome do seu usuário;
6) Em **Visibility Level** mantenha selecionada a opção **Private**;
7) Em **Initialize repository with a README** deixe como está: **desmarcada**;
8) Clique em **Create project** e aguarda o projeto ser criado no GitLab;

![Novo projeto](/Imagens/exercicio/projeto-config-2.png)

9) Das instruções do item **Push an existing Git repository**, execute apenas as três últimas no **Git Bash**:

![Importar projeto git](/Imagens/exercicio/importar-projeto.png)

10) O resultado da "importação" do projeto deve ser similar ao abaixo:

![Importar projeto git](/Imagens/exercicio/importar-projeto-git.png)

11) Após a atualização do repositório, na página do GitLab, atualize (tecle F5) e confirme que o projeto foi atualizado.

![Importar projeto git](/Imagens/exercicio/projeto-importado.png)

12) No menu esquerdo, clique em **Repository** e depois em **Graph** e veja o grafo de commits do projeto.

![Importar projeto git](/Imagens/exercicio/projeto-importado-caminho-graph.png)

![Importar projeto git](/Imagens/exercicio/projeto-importado-commit-graph.png)
