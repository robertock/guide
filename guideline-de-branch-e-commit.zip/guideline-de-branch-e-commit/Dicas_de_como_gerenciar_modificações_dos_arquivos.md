# Boas práticas para gerenciar modificações antes de fazer o commit

### Adicionar e remover arquivos modificados

Adicionar um arquivo modificado para ser commitado:
```
git add nome_arquivo
```

Remover um arquivo modificado de ser commitado:
```
git reset HEAD nome_arquivo
```

Adicionar todos os arquivos modificados para serem commitados:
```
git add .
```

Remover todos os arquivos modificados de serem commitados:
```
git reset
```

### Descartar modificações feitas

Descartar permanentemente modificações em um arquivo específico:
```
git checkout -- nome_arquivo
```

Descartar permanentemente modificações em todos os arquivos:
```
git reset --hard
```

